# King Mini Float

Dark English UI + draggable floating K button + installed-app launcher.

## GitHub build
1. Create a new GitHub repository.
2. Upload the contents of this project, including `.github`.
3. Commit to `main`.
4. Open **Actions** -> **Build Android APK**.
5. Choose **Run workflow** if needed.
6. Download the `KingMiniFloat-debug-apk` artifact from the completed run.

## Phone
Open the APK -> press **START ON** -> allow **Display over other apps** -> return to the app. The floating K button can be dragged. Tap it to open installed launcher apps.

Android security permissions must be granted by the user; the app cannot silently grant overlay permission.

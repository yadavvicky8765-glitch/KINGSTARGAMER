package com.kingminifloat;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class FloatingService extends Service {
 public static final String ACTION_START="START_FLOAT", ACTION_STOP="STOP_FLOAT";
 private WindowManager wm; private View bubble; private WindowManager.LayoutParams bp; private boolean dragging; private float downX,downY; private int sx,sy;
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();}
 @Override public int onStartCommand(Intent in,int flags,int id){ if(in!=null&&ACTION_STOP.equals(in.getAction())){removeBubble();stopForeground(true);stopSelf();return START_NOT_STICKY;} startForeground(7,notification()); if(Settings.canDrawOverlays(this)&&bubble==null)showBubble(); return START_STICKY;}
 private void showBubble(){
   TextView b=new TextView(this); b.setText("K"); b.setTextColor(Color.WHITE); b.setTextSize(20); b.setGravity(Gravity.CENTER); b.setTypeface(null,1); b.setBackgroundResource(R.drawable.bubble_bg); bubble=b;
   int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
   bp=new WindowManager.LayoutParams(dp(58),dp(58),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); bp.gravity=Gravity.TOP|Gravity.START;bp.x=dp(16);bp.y=dp(180);
   b.setOnTouchListener((v,e)->{switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:dragging=false;downX=e.getRawX();downY=e.getRawY();sx=bp.x;sy=bp.y;return true;case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-downX),dy=(int)(e.getRawY()-downY);if(Math.abs(dx)>dp(6)||Math.abs(dy)>dp(6))dragging=true;bp.x=sx+dx;bp.y=sy+dy;wm.updateViewLayout(bubble,bp);return true;case MotionEvent.ACTION_UP:if(!dragging)showPanel();return true;}return false;});
   wm.addView(b,bp);
 }
 private void showPanel(){
   LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(12),dp(12),dp(12),dp(12));panel.setBackgroundResource(R.drawable.panel_bg);
   TextView title=new TextView(this);title.setText("Installed Apps");title.setTextColor(Color.WHITE);title.setTextSize(19);title.setTypeface(null,1);title.setPadding(dp(8),dp(4),dp(8),dp(12));panel.addView(title);
   ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(330)));
   TextView close=new TextView(this);close.setText("CLOSE");close.setTextColor(Color.WHITE);close.setTextSize(14);close.setGravity(Gravity.CENTER);close.setBackgroundColor(Color.rgb(55,56,65));panel.addView(close,new LinearLayout.LayoutParams(-1,dp(45)));
   int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;WindowManager.LayoutParams pp=new WindowManager.LayoutParams(dp(300),dp(440),type,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,PixelFormat.TRANSLUCENT);pp.gravity=Gravity.CENTER;
   PackageManager pm=getPackageManager();Intent launcher=new Intent(Intent.ACTION_MAIN,null);launcher.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> apps=pm.queryIntentActivities(launcher,0);Collections.sort(apps,(a,c)->a.loadLabel(pm).toString().compareToIgnoreCase(c.loadLabel(pm).toString()));
   for(ResolveInfo ri:apps){LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(10),dp(6),dp(8),dp(6));item.setBackgroundResource(R.drawable.app_item_bg);ImageView icon=new ImageView(this);icon.setImageDrawable(ri.loadIcon(pm));item.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));TextView name=new TextView(this);name.setText(ri.loadLabel(pm));name.setTextColor(Color.WHITE);name.setTextSize(15);name.setPadding(dp(10),0,0,0);item.addView(name,new LinearLayout.LayoutParams(0,dp(54),1));item.setOnClickListener(v->{Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);launch.setComponent(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name));launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(launch);}catch(Exception ignored){}try{wm.removeView(panel);}catch(Exception ignored){}});list.addView(item,new LinearLayout.LayoutParams(-1,dp(58)));}
   close.setOnClickListener(v->{try{wm.removeView(panel);}catch(Exception ignored){}});wm.addView(panel,pp);
 }
 private Notification notification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"float").setContentTitle("King Mini Float").setContentText("Floating launcher is ON").setSmallIcon(R.drawable.ic_launcher).setContentIntent(pi).setOngoing(true).build();}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("float","Floating Launcher",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
 private void removeBubble(){if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}}
 @Override public void onDestroy(){removeBubble();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}

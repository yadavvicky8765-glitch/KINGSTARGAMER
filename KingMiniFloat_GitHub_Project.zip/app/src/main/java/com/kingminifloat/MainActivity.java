package com.kingminifloat;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    private Button toggle;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView txt(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);return t;}
    @Override public void onCreate(Bundle b){super.onCreate(b); buildUi();}
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24),dp(28),dp(24),dp(24)); root.setBackgroundColor(Color.rgb(16,17,20));
        TextView title=txt("King Mini Float",28); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView sub=txt("Floating app launcher",15); sub.setTextColor(Color.LTGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(35)));
        TextView info=txt("Turn ON to show a draggable floating button over other apps.\n\nTap the floating button to open your installed apps.",16); info.setTextColor(Color.LTGRAY); info.setPadding(0,dp(18),0,dp(18)); root.addView(info,new LinearLayout.LayoutParams(-1,0,1));
        toggle=new Button(this); toggle.setText("START ON"); toggle.setTextSize(17); root.addView(toggle,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView status=txt("Overlay permission is required.",13); status.setTextColor(Color.GRAY); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,dp(42)));
        toggle.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;} startFloat(); });
        setContentView(root);
    }
    private void startFloat(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2002);
        Intent i=new Intent(this,FloatingService.class); i.setAction(FloatingService.ACTION_START); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); toggle.setText("STOP OFF");
    }
    @Override protected void onResume(){super.onResume();}
}
